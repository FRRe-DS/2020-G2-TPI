//const {MONGO_PASSWORD} = require('./secrets.js');

module.exports = {
    MONGOURI: "mongodb+srv://prueba:villaverdecrack@cluster1dacs-ddbbz.mongodb.net/test?retryWrites=true&w=majority"
}
