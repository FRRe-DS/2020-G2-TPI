//const {MONGO_PASSWORD} = require('./secrets.js');

module.exports = {
    MONGOURI: "mongodb+srv://admin:LosFachas@alecluster-3uwzx.mongodb.net/test?retryWrites=true&w=majority"
}
