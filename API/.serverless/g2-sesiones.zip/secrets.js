module.exports = {
    MONGO_PASSWORD : "villaverdecrack",
    EXPRESS_SECRET : "tomatesverdesfritos"
}